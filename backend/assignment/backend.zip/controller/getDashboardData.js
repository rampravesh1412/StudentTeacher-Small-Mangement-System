// const Dashboardstd = require('../modles/studentDashboard');

// exports.findAllData = async(req , res) => {
//     try {
//         const data = await Dashboardstd.find();
//         console.log(data);
//         return res.status(200).json({
//             status: true,
//             message: "Data Found",
//             data: data
//         });
        
//     } catch (error) {
//         console.log(error);
        
//     }
// }
